import ReactDOM from 'react-dom';
import demo from '../../src/demo.js';

ReactDOM.render(
    demo,
    document.getElementById('app')
);
