// this sets the default `props`
export default {
    name: "Jared",
    points: 1000,
    clickAction: () => {}
};
